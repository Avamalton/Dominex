/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * DepthLiquidityBot.ts
 * Real Multi-Level Depth & Liquidity Market-Making Bot for DIMONEX.
 * Deploys multiple authentic bid and ask levels around the validated reference price
 * directly into the single-threaded authoritative Matching Engine.
 */

import { db } from '../../db/database.js';
import { matchingEngine } from '../../engine/MatchingEngine.js';
import { PrecisionMath } from '../../ledger/PrecisionMath.js';
import { priceAggregatorService } from '../external/PriceAggregatorService.js';
import { BotInstance, DepthLiquidityConfig, Order } from '../../db/types.js';

export class DepthLiquidityBotExecutor {
  /**
   * Execute a single cycle for a Depth & Liquidity Bot
   */
  public static executeCycle(
    bot: BotInstance,
    addLog: (bot: BotInstance, msg: string, type?: 'INFO' | 'ORDER' | 'FILL' | 'ERROR' | 'RISK') => void
  ): boolean {
    const cfg = bot.depthLiquidityConfig;
    if (!cfg) return false;

    const pair = db.tradingPairs.get(bot.pairId);
    if (!pair) {
      addLog(bot, `Trading pair ${bot.pairId} tidak ditemukan.`, 'ERROR');
      return false;
    }

    if (pair.isHalted) {
      addLog(bot, `Trading pair ${bot.pairId} sedang di-halt oleh Administrator.`, 'RISK');
      return false;
    }

    // 1. Get validated external reference price
    const refData = priceAggregatorService.getReferencePrice(bot.pairId);
    const now = Date.now();

    if (refData.status === 'REFERENCE_PRICE_UNAVAILABLE' || refData.isStale || refData.effectiveIdrPrice <= 0) {
      addLog(bot, `Harga referensi eksternal tidak valid atau STALE (${refData.rejectionReason || 'Stale data'}). Penyesuaian likuiditas ditangguhkan.`, 'RISK');
      this.cancelOpenDepthOrders(bot, addLog, 'Feed harga eksternal stale');
      return false;
    }

    let baseRefIdr = refData.effectiveIdrPrice;
    if (cfg.reference_price_source === 'BINANCE' && refData.binancePrice) {
      baseRefIdr = Math.round(refData.binancePrice * refData.fxRateUsed);
    } else if (cfg.reference_price_source === 'BYBIT' && refData.bybitPrice) {
      baseRefIdr = Math.round(refData.bybitPrice * refData.fxRateUsed);
    }

    const tickSize = Math.max(1, cfg.tick_size || 1000);
    const roundedRefPrice = Math.round(baseRefIdr / tickSize) * tickSize;

    // Check reprice interval
    const lastReprice = cfg.lastRepriceTimestamp || 0;
    const minInterval = Math.max(1000, cfg.minimum_reprice_interval_ms || 3000);
    if (now - lastReprice < minInterval && (cfg.activeOrderIds && cfg.activeOrderIds.length > 0)) {
      return true;
    }

    // Prepare ladder configurations
    const numBids = Math.min(10, Math.max(1, cfg.number_of_bid_levels || 3));
    const numAsks = Math.min(10, Math.max(1, cfg.number_of_ask_levels || 3));

    const bidOffsets = cfg.bid_level_offsets_bps && cfg.bid_level_offsets_bps.length > 0
      ? cfg.bid_level_offsets_bps
      : [10, 25, 50, 100];

    const askOffsets = cfg.ask_level_offsets_bps && cfg.ask_level_offsets_bps.length > 0
      ? cfg.ask_level_offsets_bps
      : [10, 25, 50, 100];

    const bidQuantities = cfg.bid_quantities && cfg.bid_quantities.length > 0
      ? cfg.bid_quantities
      : ['0.02', '0.05', '0.10', '0.20'];

    const askQuantities = cfg.ask_quantities && cfg.ask_quantities.length > 0
      ? cfg.ask_quantities
      : ['0.02', '0.05', '0.10', '0.20'];

    // Check accounts and balances
    const quoteAccount = db.createOrGetAccount(bot.accountId, pair.quoteCurrency);
    const baseAccount = db.createOrGetAccount(bot.accountId, pair.baseCurrency);
    let quoteAvailable = BigInt(quoteAccount.balanceAvailable);
    let baseAvailable = BigInt(baseAccount.balanceAvailable);
    const baseDecimals = pair.baseDecimals;

    // Cancel old active orders to refresh ladder cleanly
    if (!cfg.dry_run) {
      this.cancelOpenDepthOrders(bot, addLog, 'Rotasi reprice ladder likuiditas');
    }

    const newActiveOrderIds: string[] = [];

    // Deploy BID Ladder
    for (let i = 0; i < numBids; i++) {
      const offsetBps = bidOffsets[i % bidOffsets.length] || ((i + 1) * 15);
      const targetBidPrice = Math.round(roundedRefPrice * (1 - offsetBps / 10000) / tickSize) * tickSize;

      let qtyStr = bidQuantities[i % bidQuantities.length] || '0.02';
      if (cfg.quantity_randomization_enabled) {
        const minQ = parseFloat(cfg.random_min_quantity || '0.01');
        const maxQ = parseFloat(cfg.random_max_quantity || '0.05');
        const randQ = minQ + Math.random() * (maxQ - minQ);
        qtyStr = randQ.toFixed(4);
      }

      const qtyBaseUnits = (BigInt(Math.round(parseFloat(qtyStr) * (10 ** baseDecimals)))).toString();
      const bidPriceUnits = PrecisionMath.parseToUnits(targetBidPrice.toString(), pair.quoteDecimals);
      const neededQuote = PrecisionMath.calculateQuoteAmount(BigInt(qtyBaseUnits), baseDecimals, bidPriceUnits);

      if (quoteAvailable >= neededQuote) {
        if (cfg.dry_run) {
          addLog(bot, `[DRY-RUN] Deploy Bid Level ${i + 1}: Rp ${targetBidPrice.toLocaleString()} (Qty: ${qtyStr})`, 'INFO');
        } else {
          const clientOrderId = `bot-dp-${bot.id.slice(4, 10)}-b${i + 1}-${Date.now()}`;
          try {
            const res = matchingEngine.placeOrder({
              userId: bot.accountId,
              pairId: bot.pairId,
              side: 'BUY',
              orderType: 'LIMIT',
              timeInForce: 'GTC',
              price: bidPriceUnits.toString(),
              quantity: qtyBaseUnits,
              clientOrderId
            });

            const placedBid = res?.takerOrder || (res as any)?.order;
            if (placedBid) {
              newActiveOrderIds.push(placedBid.id);
              bot.deployedOrderIds.push(placedBid.id);
              bot.stats.ordersSubmitted++;
              bot.stats.ordersAccepted++;
              quoteAvailable -= neededQuote;
            }
          } catch (err: any) {
            addLog(bot, `Gagal memasang Bid Level ${i + 1}: ${err.message}`, 'ERROR');
          }
        }
      }
    }

    // Deploy ASK Ladder
    for (let i = 0; i < numAsks; i++) {
      const offsetBps = askOffsets[i % askOffsets.length] || ((i + 1) * 15);
      const targetAskPrice = Math.round(roundedRefPrice * (1 + offsetBps / 10000) / tickSize) * tickSize;

      let qtyStr = askQuantities[i % askQuantities.length] || '0.02';
      if (cfg.quantity_randomization_enabled) {
        const minQ = parseFloat(cfg.random_min_quantity || '0.01');
        const maxQ = parseFloat(cfg.random_max_quantity || '0.05');
        const randQ = minQ + Math.random() * (maxQ - minQ);
        qtyStr = randQ.toFixed(4);
      }

      const qtyBaseUnits = (BigInt(Math.round(parseFloat(qtyStr) * (10 ** baseDecimals)))).toString();
      const askPriceUnits = PrecisionMath.parseToUnits(targetAskPrice.toString(), pair.quoteDecimals);

      if (baseAvailable >= BigInt(qtyBaseUnits)) {
        if (cfg.dry_run) {
          addLog(bot, `[DRY-RUN] Deploy Ask Level ${i + 1}: Rp ${targetAskPrice.toLocaleString()} (Qty: ${qtyStr})`, 'INFO');
        } else {
          const clientOrderId = `bot-dp-${bot.id.slice(4, 10)}-a${i + 1}-${Date.now()}`;
          try {
            const res = matchingEngine.placeOrder({
              userId: bot.accountId,
              pairId: bot.pairId,
              side: 'SELL',
              orderType: 'LIMIT',
              timeInForce: 'GTC',
              price: askPriceUnits.toString(),
              quantity: qtyBaseUnits,
              clientOrderId
            });

            const placedAsk = res?.takerOrder || (res as any)?.order;
            if (placedAsk) {
              newActiveOrderIds.push(placedAsk.id);
              bot.deployedOrderIds.push(placedAsk.id);
              bot.stats.ordersSubmitted++;
              bot.stats.ordersAccepted++;
              baseAvailable -= BigInt(qtyBaseUnits);
            }
          } catch (err: any) {
            addLog(bot, `Gagal memasang Ask Level ${i + 1}: ${err.message}`, 'ERROR');
          }
        }
      }
    }

    cfg.activeOrderIds = newActiveOrderIds;
    cfg.lastRepriceTimestamp = now;
    bot.lastHeartbeat = now;

    if (newActiveOrderIds.length > 0) {
      addLog(bot, `Berhasil memperbarui kedalaman order book: ${newActiveOrderIds.length} level order aktif dipasang di Matching Engine.`, 'ORDER');
    }

    db.scheduleSave();
    return true;
  }

  public static cancelOpenDepthOrders(
    bot: BotInstance,
    addLog: (bot: BotInstance, msg: string, type?: 'INFO' | 'ORDER' | 'FILL' | 'ERROR' | 'RISK') => void,
    reason = 'Penghentian bot'
  ): number {
    const cfg = bot.depthLiquidityConfig;
    let count = 0;

    const idsToCancel = [...(cfg?.activeOrderIds || []), ...bot.deployedOrderIds];
    const uniqueIds = Array.from(new Set(idsToCancel));

    for (const orderId of uniqueIds) {
      const order = db.orders.get(orderId);
      if (order && (order.status === 'NEW' || order.status === 'PARTIALLY_FILLED')) {
        try {
          const res = matchingEngine.cancelOrder(orderId, bot.accountId, bot.pairId);
          if (res && res.status === 'CANCELLED') {
            count++;
          }
        } catch (e) {}
      }
    }

    if (cfg) {
      cfg.activeOrderIds = [];
    }

    if (count > 0) {
      addLog(bot, `Membatalkan ${count} order depth terbuka (${reason}).`, 'INFO');
    }
    return count;
  }
}
